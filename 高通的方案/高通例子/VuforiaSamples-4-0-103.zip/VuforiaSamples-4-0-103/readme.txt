/*==============================================================================
Copyright (c) 2012-2015 Qualcomm Connected Experiences, Inc. All Rights Reserved.

Vuforia is a trademark of QUALCOMM Incorporated, registered in the United States 
and other countries. Trademarks of QUALCOMM Incorporated are used with permission.
================================================================================*/

================================================================================


Vuforia Samples
================================================================================

Vuforia sample applications showcase key features and demonstrate basic functionality 
to help you get started. This project consists of a single sample application that demonstrates the core features of the Vuforia  SDK.
================================================================================
How to use the samples
================================================================================
Visit the Vuforia Library for instructions on how to use each sample.


================================================================================
Tips and tricks
================================================================================
Make sure that your device has an active network connection while using the 
application. 

